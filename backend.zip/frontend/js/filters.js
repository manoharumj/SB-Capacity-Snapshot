/**
 * filters.js
 * ──────────
 * Filter state, dropdown population, and the main applyFilters()
 * function that drives chart + table updates.
 */

// ── Shared mutable state ──────────────────────────────────────────
let ALL_SITES   = [];
let ALL_TREND   = [];
let ALL_REGIONS = [];
let filtered    = [];
let sortKey     = "loc_cube_util_pct";
let sortDir     = -1;   // -1 = descending, 1 = ascending

// ── Load data from the API payload ───────────────────────────────
function setData(payload) {
  ALL_SITES   = payload.sites   || [];
  ALL_TREND   = payload.trend   || [];
  ALL_REGIONS = payload.regions || [];
}

// ── Populate dropdown options ─────────────────────────────────────
function initFilters() {
  populateSelect("fRegion",  ALL_SITES.map(s => s.regionname));
  populateSelect("fType",    ALL_SITES.map(s => s.FulfillmentCenterTypeDesc));
  populateSelect("fCountry", ALL_SITES.map(s => s.Country));
}

function populateSelect(id, values) {
  const sel = document.getElementById(id);
  if (!sel) return;
  const unique = [...new Set(values.filter(Boolean))].sort();
  // Keep existing blank "All" option, remove old dynamic ones
  sel.querySelectorAll("option:not([value=''])").forEach(o => o.remove());
  unique.forEach(v => {
    const opt = document.createElement("option");
    opt.value = v;
    opt.textContent = v;
    sel.appendChild(opt);
  });
}

// ── Apply all active filters and re-render ────────────────────────
function applyFilters() {
  const region  = val("fRegion");
  const type    = val("fType");
  const country = val("fCountry");
  const outside = val("fOutside");

  filtered = ALL_SITES.filter(x => {
    if (region  && x.regionname !== region)                 return false;
    if (type    && x.FulfillmentCenterTypeDesc !== type)    return false;
    if (country && x.Country !== country)                   return false;
    if (outside === "yes" && !x.has_outside_map)            return false;
    if (outside === "no"  &&  x.has_outside_map)            return false;
    return true;
  });

  sortFiltered();
  updateKPIs(filtered);
  updateBarChart(filtered);
  updateScatterChart(filtered);
  updateTable(filtered);
}

// ── Sorting ───────────────────────────────────────────────────────
function sortFiltered() {
  filtered.sort((a, b) => sortDir * ((b[sortKey] || 0) - (a[sortKey] || 0)));
}

function onSortChange(key) {
  if (sortKey === key) {
    sortDir *= -1;
  } else {
    sortKey = key;
    sortDir = -1;
  }
  // Highlight active column header
  document.querySelectorAll("thead th").forEach(th => th.classList.remove("sorted"));
  const th = document.querySelector(`thead th[data-sort="${key}"]`);
  if (th) th.classList.add("sorted");

  applyFilters();
}

// ── Helpers ───────────────────────────────────────────────────────
function val(id) {
  const el = document.getElementById(id);
  return el ? el.value : "";
}

function median(arr) {
  const a = arr.filter(v => v != null && !isNaN(v)).sort((a, b) => a - b);
  if (!a.length) return 0;
  const m = Math.floor(a.length / 2);
  return a.length % 2 ? a[m] : (a[m - 1] + a[m]) / 2;
}
