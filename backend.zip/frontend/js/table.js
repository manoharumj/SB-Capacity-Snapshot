/**
 * table.js
 * ────────
 * Renders the site-level detail table.
 * Called by applyFilters() in filters.js whenever the dataset changes.
 */

function utilPill(v, threshHigh = 85, threshMed = 70) {
  if (v == null) return '<span class="pill pm">—</span>';
  const cls = v >= threshHigh ? "pr" : v >= threshMed ? "pa" : "pg";
  return `<span class="pill ${cls}">${v.toFixed(1)}%</span>`;
}

function mBar(v, color, max = 100) {
  const pct = Math.min(Math.max(v || 0, 0), max) / max * 100;
  return `<span class="mbar"><span class="mbar-fill" style="width:${pct}%;background:${color};"></span></span>`;
}

function updateTable(sites) {
  const tbody = document.getElementById("tBody");
  if (!tbody) return;

  if (!sites.length) {
    tbody.innerHTML = `<tr><td colspan="13" style="text-align:center;padding:24px;color:var(--muted);font-family:'IBM Plex Mono',monospace;">No sites match the current filters.</td></tr>`;
    return;
  }

  tbody.innerHTML = sites.map(s => `
    <tr>
      <td class="site-name">
        ${s.SiteName}
        ${s.has_outside_map ? '<span class="om-dot" title="Outside-map product present"></span>' : ""}
      </td>
      <td><span class="pill pb">${s.regionname || "—"}</span></td>
      <td style="color:#6b7280;font-size:10px">${s.FulfillmentCenterTypeDesc || "—"}</td>
      <td style="color:#6b7280">${s.Country || "—"}</td>
      <td>
        ${utilPill(s.loc_cube_util_pct)}
        ${mBar(s.loc_cube_util_pct, s.loc_cube_util_pct >= 85 ? "#c0392b" : s.loc_cube_util_pct >= 70 ? "#b45309" : "#1a7a4a")}
      </td>
      <td>
        ${utilPill(s.loc_fill_pct)}
        ${mBar(s.loc_fill_pct, "#1d4ed8")}
      </td>
      <td>
        ${s.product_cube_pct > 100
          ? `<span class="pill pr">${s.product_cube_pct?.toFixed(1)}%</span>`
          : utilPill(s.product_cube_pct)}
      </td>
      <td>
        ${s.has_outside_map
          ? `<span class="pill pp">⚠ ${formatCube(s.Outside_map_cube)}</span>`
          : '<span class="pill pm">—</span>'}
      </td>
      <td style="font-family:'IBM Plex Mono',monospace;font-size:10px;color:#374151">
        ${formatCube(s.Sellable_product_cube)}
      </td>
      <td>${s.dist_SKUs_sum?.toLocaleString() ?? "—"}</td>
      <td>${s.Total_Sq_ft ? s.Total_Sq_ft.toLocaleString() : "—"}</td>
      <td style="color:#6b7280">${s.FMS_LiveDate || "—"}</td>
      <td style="font-size:10px;color:#6b7280;max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
        ${s.SC_status || "—"}
      </td>
    </tr>
  `).join("");
}
