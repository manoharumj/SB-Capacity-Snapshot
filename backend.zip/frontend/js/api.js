/**
 * api.js
 * ──────
 * All communication with the FastAPI backend lives here.
 * The dashboard calls loadDashboard() once on startup.
 * Call refreshData() to force a re-fetch from the DB.
 */

const API_BASE = "http://127.0.0.1:8000";

/**
 * Fetches all dashboard data in a single round-trip (/api/all).
 * Returns { sites, trend, regions, refreshed_at }
 */
async function loadDashboard() {
  showLoadingState(true);
  try {
    const res = await fetch(`${API_BASE}/api/all`);
    if (!res.ok) throw new Error(`API error: ${res.status} ${res.statusText}`);
    const payload = await res.json();
    showLoadingState(false);
    updateRefreshedAt(payload.refreshed_at);
    updateDataSource(payload.data_source);
    return payload;
  } catch (err) {
    showLoadingState(false);
    showError(err.message);
    throw err;
  }
}

/**
 * Hits /api/refresh to bust the server cache and re-run SQL queries.
 * Then reloads the full dashboard.
 */
async function refreshData() {
  const btn = document.getElementById("btnRefresh");
  if (btn) { btn.textContent = "Refreshing…"; btn.disabled = true; }
  try {
    const res = await fetch(`${API_BASE}/api/refresh`);
    if (!res.ok) throw new Error(`Refresh failed: ${res.status}`);
    const data = await loadDashboard();
    if (btn) { btn.textContent = "↻ Refresh"; btn.disabled = false; }
    return data;
  } catch (err) {
    if (btn) { btn.textContent = "↻ Refresh"; btn.disabled = false; }
    showError(err.message);
    throw err;
  }
}

/** Show/hide the loading overlay */
function showLoadingState(loading) {
  const overlay = document.getElementById("loadingOverlay");
  if (overlay) overlay.style.display = loading ? "flex" : "none";
}

/** Show an error banner */
function showError(message) {
  const el = document.getElementById("errorBanner");
  if (!el) return;
  el.textContent = `⚠ ${message}`;
  el.style.display = "block";
  setTimeout(() => { el.style.display = "none"; }, 8000);
}

/** Update the "Last updated" timestamp in the header */
function updateRefreshedAt(ts) {
  const el = document.getElementById("refreshedAt");
  if (el && ts) el.textContent = `Last updated: ${ts}`;
}

/** Update the LIVE/NOT LIVE badge and subtitle based on data source */
function updateDataSource(source) {
  const badge    = document.getElementById("liveBadge");
  const meta     = document.getElementById("headerMeta");
  const isLive   = source === "live";

  if (badge) {
    badge.textContent = isLive ? "LIVE" : "NOT LIVE";
    badge.style.background   = isLive ? "#6ee7b7" : "#f87171";
    badge.style.color        = isLive ? "#1a1a18" : "#1a1a18";
  }
  if (meta) {
    meta.textContent = isLive
      ? "Universe of Capacity + Historical Capacity · live from SQL Server"
      : "Universe of Capacity + Historical Capacity · loaded from Excel fallback";
  }
}