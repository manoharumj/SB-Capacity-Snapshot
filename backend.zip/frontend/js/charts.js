/**
 * charts.js
 * ─────────
 * All Chart.js initialisation and update functions.
 * Reads from the shared state in filters.js (ALL_TREND, ALL_REGIONS).
 */

const REGION_COLORS = {
  "Northeast":  "#1d4ed8",
  "West Coast": "#0891b2",
  "Midwest":    "#7c3aed",
  "Southwest":  "#b45309",
  "Southeast":  "#0f766e",
  "Canada":     "#be123c",
  "UK":         "#1a7a4a",
  "Australia":  "#9333ea",
  "Europe":     "#6d28d9",
};

const TOOLTIP_DEFAULTS = {
  backgroundColor: "#1a1a18",
  titleColor:      "#e5e7eb",
  bodyColor:       "#9ca3af",
  padding:         10,
  boxPadding:      4,
};

let charts = {};
let trendMetric = "loc_cube_util_pct";

const METRIC_LABELS = {
  loc_cube_util_pct: "Loc Cube Util %",
  loc_fill_pct:      "Loc Fill Rate %",
  product_cube_pct:  "Product Cube %",
  dist_SKUs_sum:     "SKUs (zonal)",
  Total_Sq_ft:       "Total Sq Ft",
};

function dc(id) {
  if (charts[id]) { charts[id].destroy(); delete charts[id]; }
}

function barColor(v) {
  return v >= 85 ? "#c0392b" : v >= 70 ? "#b45309" : "#1a7a4a";
}

function formatCube(v) {
  if (!v) return "—";
  return v >= 1e6 ? (v / 1e6).toFixed(2) + "M cu" : (v / 1000).toFixed(1) + "K cu";
}

// ── KPI cards ─────────────────────────────────────────────────────
function updateKPIs(sites) {
  setText("kpiSites",   sites.length);
  setText("kpiLocCube", median(sites.map(x => x.loc_cube_util_pct)).toFixed(1) + "%");
  setText("kpiLocFill", median(sites.map(x => x.loc_fill_pct)).toFixed(1) + "%");
  setText("kpiRisk",    sites.filter(x => x.loc_cube_util_pct >= 85).length);
  setText("kpiOutside", sites.filter(x => x.has_outside_map).length);
  const sqft = sites.reduce((a, b) => a + (b.Total_Sq_ft || 0), 0);
  setText("kpiSqft",   (sqft / 1e6).toFixed(1) + "M");
}

function setText(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val;
}

// ── Bar chart ─────────────────────────────────────────────────────
function updateBarChart(sites) {
  dc("bar");
  const barMetric = document.getElementById("fMetric")?.value || "loc_cube_util_pct";
  const label     = METRIC_LABELS[barMetric] || barMetric;
  const data      = [...sites].sort((a, b) => (b[barMetric] || 0) - (a[barMetric] || 0));

  // Update panel title dynamically
  const title = document.getElementById("barTitle");
  if (title) title.textContent = `${label} by Site — Latest Snapshot`;

  const ctx = document.getElementById("cBar")?.getContext("2d");
  if (!ctx) return;

  const isPercent = ["loc_cube_util_pct", "loc_fill_pct", "product_cube_pct"].includes(barMetric);

  charts.bar = new Chart(ctx, {
    type: "bar",
    data: {
      labels:   data.map(s => s.SiteName.split(" ").slice(0, 2).join(" ")),
      datasets: [{
        label:           label,
        data:            data.map(s => s[barMetric] || 0),
        backgroundColor: data.map(s => barColor(s.loc_cube_util_pct) + "cc"),
        borderColor:     data.map(s => barColor(s.loc_cube_util_pct)),
        borderWidth: 1, borderRadius: 2,
      }],
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          ...TOOLTIP_DEFAULTS,
          callbacks: {
            title:  items => data[items[0].dataIndex].SiteName,
            label:  item  => {
              const s = data[item.dataIndex];
              return [
                ` Loc Cube Util:  ${s.loc_cube_util_pct?.toFixed(1)}%`,
                ` Loc Fill Rate:  ${s.loc_fill_pct?.toFixed(1)}%`,
                ` Product Cube %: ${s.product_cube_pct?.toFixed(1)}%`,
                ` Outside Map:    ${s.has_outside_map ? "⚠ YES (" + formatCube(s.Outside_map_cube) + ")" : "No"}`,
                ` Sellable Cube:  ${formatCube(s.Sellable_product_cube)}`,
                ` SKUs (zonal):   ${s.dist_SKUs_sum?.toLocaleString() ?? "—"}`,
              ];
            },
          },
        },
      },
      scales: {
        x: { ticks: { color: "#6b7280", font: { size: 9, family: "IBM Plex Mono" }, maxRotation: 55 }, grid: { color: "#f0ede8" } },
        y: {
          ticks: { color: "#6b7280", font: { size: 9, family: "IBM Plex Mono" }, callback: v => isPercent ? v + "%" : v.toLocaleString() },
          grid:  { color: "#f0ede8" },
          max:   isPercent && barMetric !== "product_cube_pct" ? 100 : undefined,
          title: { display: true, text: label, color: "#6b7280", font: { size: 10 } },
        },
      },
    },
  });
}

// ── Trend chart ───────────────────────────────────────────────────
function setTrendMetric(metric, btn) {
  trendMetric = metric;
  document.querySelectorAll(".tab-btn").forEach(b => {
    b.style.borderColor = "var(--border)";
    b.style.background  = "var(--panel2)";
    b.style.color       = "var(--muted)";
  });
  btn.style.borderColor = "var(--blue)";
  btn.style.background  = "var(--blue-bg)";
  btn.style.color       = "var(--blue)";
  buildTrendChart();
}

function buildTrendChart() {
  dc("trend");
  const regions = [...new Set(ALL_TREND.map(d => d.regionname))].sort();
  const weeks   = [...new Set(ALL_TREND.map(d => d.weekstart))].sort();
  const label   = METRIC_LABELS[trendMetric] || trendMetric;

  const datasets = regions.map(r => ({
    label:           r,
    data:            weeks.map(w => { const row = ALL_TREND.find(d => d.regionname === r && d.weekstart === w); return row ? row[trendMetric] : null; }),
    borderColor:     REGION_COLORS[r] || "#6b7280",
    backgroundColor: (REGION_COLORS[r] || "#6b7280") + "18",
    borderWidth: 2, pointRadius: 0, tension: 0.3, spanGaps: true,
  }));

  const ctx = document.getElementById("cTrend")?.getContext("2d");
  if (!ctx) return;

  charts.trend = new Chart(ctx, {
    type: "line",
    data: { labels: weeks.filter((_, i) => i % 4 === 0), datasets },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: {
        legend: { labels: { color: "#6b7280", font: { size: 9, family: "IBM Plex Mono" }, boxWidth: 12 } },
        tooltip: { ...TOOLTIP_DEFAULTS },
      },
      scales: {
        x: { ticks: { color: "#6b7280", font: { size: 9, family: "IBM Plex Mono" }, maxTicksLimit: 8 }, grid: { color: "#f0ede8" } },
        y: { ticks: { color: "#6b7280", font: { size: 9, family: "IBM Plex Mono" }, callback: v => v + "%" }, grid: { color: "#f0ede8" },
             title: { display: true, text: label, color: "#6b7280", font: { size: 10 } } },
      },
    },
  });
}

// ── Scatter chart ─────────────────────────────────────────────────
function updateScatterChart(sites) {
  dc("scatter");
  const regions  = [...new Set(sites.map(s => s.regionname))];
  const datasets = regions.map(r => {
    const col = REGION_COLORS[r] || "#6b7280";
    const pts  = sites.filter(s => s.regionname === r && s.Total_Sq_ft > 0);
    return {
      label:           r,
      data:            pts.map(s => ({ x: s.Total_Sq_ft, y: s.loc_cube_util_pct, s })),
      backgroundColor: pts.map(s => s.has_outside_map ? col + "ff" : col + "88"),
      borderColor:     pts.map(s => s.has_outside_map ? "#6d28d9" : col),
      borderWidth:     pts.map(s => s.has_outside_map ? 2 : 1),
      pointRadius: 6,
      pointStyle:  pts.map(s => s.has_outside_map ? "triangle" : "circle"),
    };
  });

  const ctx = document.getElementById("cScatter")?.getContext("2d");
  if (!ctx) return;

  charts.scatter = new Chart(ctx, {
    type: "scatter", data: { datasets },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: {
        legend: { labels: { color: "#6b7280", font: { size: 9, family: "IBM Plex Mono" }, boxWidth: 12 } },
        tooltip: { ...TOOLTIP_DEFAULTS, callbacks: { label: ctx => {
          const s = ctx.raw.s;
          return [` ${s.SiteName}`, ` Loc Cube: ${s.loc_cube_util_pct?.toFixed(1)}%`, ` Sq Ft: ${s.Total_Sq_ft?.toLocaleString()}`, s.has_outside_map ? " ⚠ Outside-map" : ""].filter(Boolean);
        }}},
      },
      scales: {
        x: { ticks: { color: "#6b7280", font: { size: 9, family: "IBM Plex Mono" }, callback: v => (v / 1000).toFixed(0) + "K" }, grid: { color: "#f0ede8" },
             title: { display: true, text: "Total Sq Ft", color: "#6b7280", font: { size: 10 } } },
        y: { ticks: { color: "#6b7280", font: { size: 9, family: "IBM Plex Mono" }, callback: v => v + "%" }, grid: { color: "#f0ede8" }, max: 100,
             title: { display: true, text: "Loc Cube Util %", color: "#6b7280", font: { size: 10 } } },
      },
    },
  });
}

// ── Region chart ──────────────────────────────────────────────────
function buildRegionChart() {
  dc("region");
  const ctx = document.getElementById("cRegion")?.getContext("2d");
  if (!ctx) return;
  charts.region = new Chart(ctx, {
    type: "bar",
    data: {
      labels:   ALL_REGIONS.map(r => r.regionname),
      datasets: [
        { type: "bar",  label: "Loc Cube Util %", data: ALL_REGIONS.map(r => r.med_loc_cube_util),
          backgroundColor: ALL_REGIONS.map(r => (REGION_COLORS[r.regionname] || "#6b7280") + "cc"), borderRadius: 2, yAxisID: "y" },
        { type: "line", label: "Loc Fill Rate %", data: ALL_REGIONS.map(r => r.med_loc_fill),
          borderColor: "#1a1a18", backgroundColor: "transparent", borderWidth: 2,
          pointRadius: 4, pointBackgroundColor: "#1a1a18", tension: 0.2, yAxisID: "y" },
      ],
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: {
        legend: { labels: { color: "#6b7280", font: { size: 9, family: "IBM Plex Mono" }, boxWidth: 12 } },
        tooltip: { ...TOOLTIP_DEFAULTS, callbacks: { afterBody: items => {
          const r = ALL_REGIONS[items[0].dataIndex];
          return [`Sites: ${r.sites}`, `Outside-map sites: ${r.outside_map_sites}`, `Median Product Cube %: ${r.med_product_cube}%`];
        }}},
      },
      scales: {
        x: { ticks: { color: "#6b7280", font: { size: 9, family: "IBM Plex Mono" } }, grid: { color: "#f0ede8" } },
        y: { ticks: { color: "#6b7280", font: { size: 9, family: "IBM Plex Mono" }, callback: v => v + "%" }, grid: { color: "#f0ede8" }, max: 100 },
      },
    },
  });
}

// ── Histogram ─────────────────────────────────────────────────────
function buildHistChart() {
  dc("hist");
  const bins = [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100];
  const labels = bins.slice(0, -1).map((b, i) => `${b}–${bins[i + 1]}`);
  const cubeAll = new Array(bins.length - 1).fill(0);
  const cubeOut = new Array(bins.length - 1).fill(0);
  const fillAll = new Array(bins.length - 1).fill(0);
  const fillOut = new Array(bins.length - 1).fill(0);

  ALL_SITES.forEach(s => {
    for (let i = 0; i < bins.length - 1; i++) {
      if (s.loc_cube_util_pct >= bins[i] && s.loc_cube_util_pct < bins[i + 1]) {
        cubeAll[i]++; if (s.has_outside_map) cubeOut[i]++; break;
      }
    }
    for (let i = 0; i < bins.length - 1; i++) {
      if (s.loc_fill_pct >= bins[i] && s.loc_fill_pct < bins[i + 1]) {
        fillAll[i]++; if (s.has_outside_map) fillOut[i]++; break;
      }
    }
  });

  const ctx = document.getElementById("cHist")?.getContext("2d");
  if (!ctx) return;
  charts.hist = new Chart(ctx, {
    type: "bar",
    data: { labels, datasets: [
      { label: "Loc Cube Util (no outside map)", data: cubeAll.map((c, i) => c - cubeOut[i]), backgroundColor: "#1a7a4a55", borderColor: "#1a7a4a", borderWidth: 1, borderRadius: 2, stack: "cube" },
      { label: "Loc Cube Util (outside map ⚠)",  data: cubeOut, backgroundColor: "#6d28d955", borderColor: "#6d28d9", borderWidth: 1, borderRadius: 2, stack: "cube" },
      { label: "Loc Fill Rate (no outside map)", data: fillAll.map((c, i) => c - fillOut[i]), backgroundColor: "#1d4ed855", borderColor: "#1d4ed8", borderWidth: 1, borderRadius: 2, stack: "fill" },
      { label: "Loc Fill Rate (outside map ⚠)",  data: fillOut, backgroundColor: "#be123c55", borderColor: "#be123c", borderWidth: 1, borderRadius: 2, stack: "fill" },
    ]},
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: {
        legend: { labels: { color: "#6b7280", font: { size: 9, family: "IBM Plex Mono" }, boxWidth: 10 } },
        tooltip: { ...TOOLTIP_DEFAULTS },
      },
      scales: {
        x: { ticks: { color: "#6b7280", font: { size: 9, family: "IBM Plex Mono" }, maxRotation: 45 }, grid: { color: "#f0ede8" }, stacked: true },
        y: { ticks: { color: "#6b7280", font: { size: 9, family: "IBM Plex Mono" } }, grid: { color: "#f0ede8" }, stacked: true,
             title: { display: true, text: "# Sites", color: "#6b7280", font: { size: 10 } } },
      },
    },
  });
}
