"""
cache.py
────────
TTL cache with file persistence.
- On get: checks memory first, then disk if memory is cold (e.g. after restart)
- On set: writes to memory AND disk
- On invalidate: clears both memory and disk
- TTL is enforced on both layers
TTL is configured via CACHE_TTL_MINUTES in .env (default: 60 minutes).
"""

import json
import logging
import time
from pathlib import Path
from typing import Any

from backend.config import settings

logger = logging.getLogger(__name__)

# Cache file lives next to this file in the backend/ folder
CACHE_FILE = Path(__file__).resolve().parent / ".cache.json"


class TTLCache:
    def __init__(self, ttl_minutes: int):
        self._ttl = ttl_minutes * 60  # seconds
        self._store: dict[str, tuple[float, Any]] = {}

    # ── Memory helpers ────────────────────────────────────────────────

    def _mem_get(self, key: str) -> Any | None:
        if key not in self._store:
            return None
        timestamp, value = self._store[key]
        if time.time() - timestamp > self._ttl:
            del self._store[key]
            return None
        return value

    def _mem_set(self, key: str, value: Any, timestamp: float) -> None:
        self._store[key] = (timestamp, value)

    # ── Disk helpers ──────────────────────────────────────────────────

    def _disk_read(self) -> dict:
        try:
            if CACHE_FILE.exists():
                return json.loads(CACHE_FILE.read_text(encoding="utf-8"))
        except Exception as e:
            logger.warning("Cache file unreadable, ignoring: %s", e)
        return {}

    def _disk_write(self, store: dict) -> None:
        try:
            CACHE_FILE.write_text(
                json.dumps(store, default=str), encoding="utf-8"
            )
        except Exception as e:
            logger.warning("Could not write cache file: %s", e)

    def _disk_clear(self) -> None:
        try:
            if CACHE_FILE.exists():
                CACHE_FILE.unlink()
        except Exception as e:
            logger.warning("Could not delete cache file: %s", e)

    # ── Public API ────────────────────────────────────────────────────

    def get(self, key: str) -> Any | None:
        # 1. Check memory
        value = self._mem_get(key)
        if value is not None:
            return value

        # 2. Fall back to disk (cold start / restart)
        disk = self._disk_read()
        if key not in disk:
            return None
        timestamp, value = disk[key]["timestamp"], disk[key]["value"]
        if time.time() - timestamp > self._ttl:
            logger.info("Disk cache expired for key '%s'", key)
            return None

        logger.info("Loaded key '%s' from disk cache (age: %ds)", key, int(time.time() - timestamp))
        self._mem_set(key, value, timestamp)  # warm memory from disk
        return value

    def set(self, key: str, value: Any) -> None:
        timestamp = time.time()
        self._mem_set(key, value, timestamp)

        # Persist to disk
        disk = self._disk_read()
        disk[key] = {"timestamp": timestamp, "value": value}
        self._disk_write(disk)
        logger.info("Cache written to disk for key '%s'", key)

    def invalidate(self, key: str = None) -> None:
        """Pass a key to clear one entry, or None to clear everything."""
        if key:
            self._store.pop(key, None)
            disk = self._disk_read()
            disk.pop(key, None)
            self._disk_write(disk)
        else:
            self._store.clear()
            self._disk_clear()

    def age_seconds(self, key: str) -> int | None:
        if key in self._store:
            timestamp, _ = self._store[key]
            return int(time.time() - timestamp)
        # Check disk if not in memory
        disk = self._disk_read()
        if key in disk:
            return int(time.time() - disk[key]["timestamp"])
        return None


# Single shared instance used across the app
cache = TTLCache(ttl_minutes=settings.cache_ttl_minutes)