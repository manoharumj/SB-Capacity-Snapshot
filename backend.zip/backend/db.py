import logging
import pandas as pd
from pathlib import Path
from sqlalchemy import create_engine, text
from backend.config import settings

logger = logging.getLogger(__name__)

QUERIES_DIR = Path(__file__).resolve().parent / "queries"
EXCEL_FILE  = Path(__file__).resolve().parent.parent / "data" / "fallback.xlsx"


def get_engine():
    # ActiveDirectoryInteractive = MFA popup via Azure Entra ID
    # autocommit=True set on pyodbc directly — Synapse does not support
    # SQLAlchemy-level isolation level settings
    odbc_str = (
        f"DRIVER={{ODBC Driver 18 for SQL Server}};"
        f"SERVER={settings.db_server};"
        f"DATABASE={settings.db_database};"
        f"UID={settings.db_username};"
        f"Authentication=ActiveDirectoryInteractive;"
        f"Encrypt=yes;TrustServerCertificate=no;"
        f"LoginTimeout=30;ConnectTimeout=30;"
    )
    import pyodbc
    creator = lambda: pyodbc.connect(odbc_str, autocommit=True)
    return create_engine("mssql+pyodbc://", creator=creator)


def run_query(sql: str) -> pd.DataFrame:
    """
    Executes a SQL string and returns results as a DataFrame.
    Creates a fresh engine + connection per query to avoid stale
    MFA tokens or closed connection issues with Synapse.
    """
    import pyodbc
    odbc_str = (
        f"DRIVER={{ODBC Driver 18 for SQL Server}};"
        f"SERVER={settings.db_server};"
        f"DATABASE={settings.db_database};"
        f"UID={settings.db_username};"
        f"Authentication=ActiveDirectoryInteractive;"
        f"Encrypt=yes;TrustServerCertificate=no;"
        f"LoginTimeout=30;ConnectTimeout=30;"
    )
    conn = pyodbc.connect(odbc_str, autocommit=True)
    try:
        df = pd.read_sql(sql, conn)
        logger.info("Query columns: %s", list(df.columns))
    finally:
        conn.close()
    return df


def load_sql(filename: str) -> str:
    """Reads a .sql file from the queries/ directory."""
    path = QUERIES_DIR / filename
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def load_excel_fallback() -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Loads universe + historical data from the fallback Excel file.
    Expected sheets: 'universe' and 'historical'.
    Returns (df_universe, df_historical).
    """
    if not EXCEL_FILE.exists():
        raise FileNotFoundError(
            f"Fallback Excel not found at {EXCEL_FILE}. "
            "Export your data and save it as data/fallback.xlsx with "
            "sheets named 'universe' and 'historical'."
        )
    logger.info("Loading fallback data from %s", EXCEL_FILE)
    df_universe   = pd.read_excel(EXCEL_FILE, sheet_name="universe")
    df_historical = pd.read_excel(EXCEL_FILE, sheet_name="historical")

    return df_universe, df_historical


def normalise_columns(df_universe: pd.DataFrame, df_historical: pd.DataFrame):
    """Normalise column names from either source to match transform.py expectations."""
    df_universe   = df_universe.rename(columns={"RegionName": "regionname"})
    df_historical = df_historical.rename(columns={"Occupied_cube_capacity": "Product_cube_stored"})
    return df_universe, df_historical


def load_data() -> tuple[pd.DataFrame, pd.DataFrame, str]:
    """
    Try live DB first. On any failure, fall back to Excel.
    Returns (df_universe, df_historical, source)
    where source is 'live' or 'excel'.
    """
    try:
        logger.info("Attempting live DB connection...")
        df_universe   = run_query(load_sql("universe.sql"))
        df_historical = run_query(load_sql("historical.sql"))
        logger.info("Live DB load successful.")
        df_universe, df_historical = normalise_columns(df_universe, df_historical)
        return df_universe, df_historical, "live"
    except Exception as e:
        logger.warning("DB connection failed (%s). Falling back to Excel.", e)
        df_universe, df_historical = load_excel_fallback()
        return df_universe, df_historical, "excel"