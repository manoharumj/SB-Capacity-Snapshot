from pydantic_settings import BaseSettings
from dotenv import load_dotenv
import os

load_dotenv()

class Settings(BaseSettings):
    db_server:   str = os.getenv("DB_SERVER", "")
    db_database: str = os.getenv("DB_DATABASE", "")
    db_username: str = os.getenv("DB_USERNAME", "")
    db_password: str = os.getenv("DB_PASSWORD", "")
    db_driver:   str = os.getenv("DB_DRIVER", "ODBC Driver 18 for SQL Server")

    app_host:          str = os.getenv("APP_HOST", "127.0.0.1")
    app_port:          int = int(os.getenv("APP_PORT", "8000"))
    cache_ttl_minutes: int = int(os.getenv("CACHE_TTL_MINUTES", "60"))

settings = Settings()