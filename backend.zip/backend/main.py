"""
main.py
───────
FastAPI application entry point.
Run locally with:
    uvicorn backend.main:app --reload --host 127.0.0.1 --port 8000
"""

import logging
import traceback
from datetime import datetime
from pathlib import Path

from fastapi import FastAPI, HTTPException

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from backend.cache import cache

# Resolve paths relative to this file so uvicorn can be run from any directory
BASE_DIR = Path(__file__).resolve().parent.parent
FRONTEND_DIR = BASE_DIR / "frontend"
from backend.db import load_data
from backend.transform import (
    aggregate_site_week,
    build_region_summary,
    build_trend,
    clean_universe,
    enrich_historical,
    latest_snapshot,
    merge_universe,
    to_records,
)

app = FastAPI(
    title="Capacity Intelligence API",
    description="Fulfillment Network Capacity Dashboard — internal tool",
    version="1.0.0",
)

# Allow the frontend (served separately during dev) to call the API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5500", "http://127.0.0.1:5500", "http://localhost:8000"],
    allow_methods=["GET"],
    allow_headers=["*"],
)

# Serve the frontend folder as static files at /static
app.mount("/static", StaticFiles(directory=str(FRONTEND_DIR)), name="static")


# ─────────────────────────────────────────────────────────────────────────────
# INTERNAL HELPERS
# ─────────────────────────────────────────────────────────────────────────────

CACHE_KEY = "dashboard_payload"


def build_payload() -> dict:
    """
    Load data (live DB or Excel fallback), apply all transformations, and return
    the complete dashboard payload as a JSON-serialisable dict.
    """
    # 1. Load raw data — live DB or Excel fallback
    df_universe, df_historical, data_source = load_data()

    # 2. Clean universe
    universe = clean_universe(df_universe)

    # 3. Enrich and aggregate historical
    enriched  = enrich_historical(df_historical)
    site_week = aggregate_site_week(enriched)

    # Diagnostic — log latest snapshot stats
    logger.info("site_week shape: %s, weekstart range: %s to %s",
        site_week.shape,
        site_week["weekstart"].min(),
        site_week["weekstart"].max()
    )
    logger.info("Sample loc_cube_util_pct: %s", site_week["loc_cube_util_pct"].describe().to_dict())

    # 4. Latest snapshot merged with universe
    latest = latest_snapshot(site_week)
    merged = merge_universe(latest, universe)

    # 5. Trend + region summary
    trend   = build_trend(site_week)
    regions = build_region_summary(merged)

    return {
        "sites":        to_records(merged),
        "trend":        to_records(trend),
        "regions":      to_records(regions),
        "refreshed_at": datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC"),
        "data_source":  data_source,   # "live" or "excel"
    }


def get_payload() -> dict:
    """Return cached payload or build a fresh one."""
    cached = cache.get(CACHE_KEY)
    if cached:
        return cached
    payload = build_payload()
    cache.set(CACHE_KEY, payload)
    return payload


# ─────────────────────────────────────────────────────────────────────────────
# ROUTES
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/")
def serve_dashboard():
    """Serve the dashboard HTML."""
    return FileResponse(str(FRONTEND_DIR / "index.html"))


@app.get("/api/sites")
def get_sites():
    """
    Latest snapshot per site, merged with Universe of Capacity.
    Includes all utilisation metrics and site metadata.
    """
    try:
        return {"data": get_payload()["sites"], "refreshed_at": get_payload()["refreshed_at"]}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/trend")
def get_trend():
    """
    Weekly median utilisation metrics per region.
    Used for the trend line chart (Jan 2023 – present).
    """
    try:
        return {"data": get_payload()["trend"], "refreshed_at": get_payload()["refreshed_at"]}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/regions")
def get_regions():
    """
    Region-level summary: median cube util, loc fill, sq ft, site count.
    """
    try:
        return {"data": get_payload()["regions"], "refreshed_at": get_payload()["refreshed_at"]}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/all")
def get_all():
    """
    Single endpoint that returns all dashboard data in one call.
    Used by the frontend on initial load to minimise round trips.
    """
    try:
        payload = get_payload()
        age = cache.age_seconds(CACHE_KEY)
        return {**payload, "cache_age_seconds": age}
    except Exception as e:
        logger.error("ERROR in /api/all:\n%s", traceback.format_exc())
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/refresh")
def refresh():
    """
    Force a cache bust and re-run both SQL queries.
    Call this after an upstream data update.
    """
    try:
        cache.invalidate(CACHE_KEY)
        payload = build_payload()
        cache.set(CACHE_KEY, payload)
        return {
            "status": "refreshed",
            "sites":   len(payload["sites"]),
            "refreshed_at": payload["refreshed_at"],
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/health")
def health():
    """Quick liveness check — confirms API is up and cache status."""
    age = cache.age_seconds(CACHE_KEY)
    return {
        "status":           "ok",
        "cache_loaded":     age is not None,
        "cache_age_seconds": age,
    }