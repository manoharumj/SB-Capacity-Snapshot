"""
transform.py
────────────
All aggregation and metric computation logic lives here.
Mirrors exactly the pandas logic validated during the analysis phase.
Input:  raw DataFrames from SQL queries
Output: clean dicts ready to be returned as JSON by the API
"""

import numpy as np
import pandas as pd


# ─────────────────────────────────────────────────────────────────────────────
# UNIVERSE
# ─────────────────────────────────────────────────────────────────────────────

def clean_universe(df: pd.DataFrame) -> pd.DataFrame:
    """
    Deduplicate universe (identical rows for same SiteName are an upstream
    data issue — safe to keep first occurrence).
    """
    df = df.drop_duplicates(subset="SiteName", keep="first").copy()
    df["Country"] = df["Country"].astype(str).str.strip()
    df["FMS_LiveDate"] = pd.to_datetime(df["FMS_LiveDate"], errors="coerce").dt.strftime("%Y-%m-%d")
    df["Total_Sq_ft"] = pd.to_numeric(df["Total_Sq_ft"], errors="coerce").fillna(0)
    return df


# ─────────────────────────────────────────────────────────────────────────────
# HISTORICAL — per-row derived fields
# ─────────────────────────────────────────────────────────────────────────────

def enrich_historical(df: pd.DataFrame) -> pd.DataFrame:
    """
    Add pre-aggregation derived columns to the raw historical DataFrame.
    Column names use the agreed mapping:
        Total_cube_capacity_occupied = All occupied WMS locations → cube
        Product_cube_stored          = Actual product volume in WMS
        CubeStoredOutsideMap         = Product outside mapped locations
        Packaging_mat_cube           = Packaging material volume
    """
    df = df.copy()
    df["weekstart"] = pd.to_datetime(df["weekstart"], errors="coerce")
    # Date granularity is handled in SQL:
    # pre-2026 = month start, 2026+ = Sunday week start

    # Null-safe numeric fills for cube fields
    df["outside_map_cube"] = pd.to_numeric(df["CubeStoredOutsideMap"], errors="coerce").fillna(0)
    df["packaging_cube"]   = pd.to_numeric(df["Packaging_mat_cube"],  errors="coerce").fillna(0)
    df["product_cube"]     = pd.to_numeric(df["Product_cube_stored"],  errors="coerce").fillna(0)

    # Sellable = product stored minus packaging material
    df["sellable_cube"] = (df["product_cube"] - df["packaging_cube"]).clip(lower=0)

    # Total stored including outside-map
    df["total_stored_cube"] = df["product_cube"] + df["outside_map_cube"]

    return df


# ─────────────────────────────────────────────────────────────────────────────
# HISTORICAL — site × week aggregation
# ─────────────────────────────────────────────────────────────────────────────

def aggregate_site_week(df: pd.DataFrame) -> pd.DataFrame:
    """
    Collapse TypeId rows → one row per (period_start, SiteName).
    Pre-2026 rows are snapped to month start; 2026+ kept at week start.
    Capacity fields are summed across zones; ratios recomputed after summing.
    """
    agg = df.groupby(["weekstart", "SiteName", "regionname"], as_index=False).agg(
        Total_cube_capacity     =("Total_cube_capacity",              "sum"),
        Occ_loc_cube            =("Total_cube_capacity_occupied",     "sum"),
        Product_cube_stored     =("product_cube",                     "sum"),
        Outside_map_cube        =("outside_map_cube",                 "sum"),
        Packaging_cube          =("packaging_cube",                   "sum"),
        Sellable_product_cube   =("sellable_cube",                    "sum"),
        Total_reachable_locs    =("Total_reachable_locs",             "sum"),
        Occupied_reachable_locs =("Occupied_reachable_locs",          "sum"),
        Created_locs            =("CreatedLocations",                 "sum"),
        Occupied_locs_total     =("OccupiedLocations",                "sum"),
        dist_SKUs_sum           =("dist_SKUs",                        "sum"),
        TypeId_count            =("TypeId",                           "nunique"),
    )

    # ── Primary utilisation metrics ───────────────────────────────────────
    # Loc Cube Util: WMS location occupancy (bounded ≤ 100% by definition)
    agg["loc_cube_util_pct"] = (
        agg["Occ_loc_cube"] / agg["Total_cube_capacity"].replace(0, np.nan) * 100
    ).round(2)

    # Product Cube %: actual product volume vs mapped capacity (can exceed 100%)
    agg["product_cube_pct"] = (
        agg["Product_cube_stored"] / agg["Total_cube_capacity"].replace(0, np.nan) * 100
    ).round(2)

    # Loc Fill Rate: reachable locations used
    agg["loc_fill_pct"] = (
        agg["Occupied_reachable_locs"] / agg["Total_reachable_locs"].replace(0, np.nan) * 100
    ).round(2)

    # Outside-map flag
    agg["has_outside_map"] = agg["Outside_map_cube"] > 0

    agg["weekstart"] = agg["weekstart"].dt.strftime("%Y-%m-%d")
    return agg


# ─────────────────────────────────────────────────────────────────────────────
# LATEST SNAPSHOT — one row per site
# ─────────────────────────────────────────────────────────────────────────────

def latest_snapshot(site_week: pd.DataFrame) -> pd.DataFrame:
    return (
        site_week
        .sort_values("weekstart")
        .groupby("SiteName", as_index=False)
        .last()
    )


# ─────────────────────────────────────────────────────────────────────────────
# MERGE universe onto latest snapshot
# ─────────────────────────────────────────────────────────────────────────────

UNIVERSE_COLS = [
    "SiteName", "regionname", "FMS_LiveDate", "Total_Sq_ft", "SB_Sq_ft",
    "FulfillmentCenterTypeDesc", "Country", "SC_status", "Hub",
    "WC_TempControl_flag", "WC_DG_flag", "WC_Haz_flag",
]

def merge_universe(latest: pd.DataFrame, universe: pd.DataFrame) -> pd.DataFrame:
    available_cols = [c for c in UNIVERSE_COLS if c in universe.columns]
    merged = latest.merge(universe[available_cols], on="SiteName", how="left")
    merged["Total_Sq_ft"] = merged["Total_Sq_ft"].fillna(0)
    return merged


# ─────────────────────────────────────────────────────────────────────────────
# TREND — regional medians by week
# ─────────────────────────────────────────────────────────────────────────────

def build_trend(site_week: pd.DataFrame) -> pd.DataFrame:
    trend = site_week.groupby(["weekstart", "regionname"], as_index=False).agg(
        sites                =("SiteName",         "nunique"),
        loc_cube_util_pct    =("loc_cube_util_pct","median"),
        loc_fill_pct         =("loc_fill_pct",     "median"),
        product_cube_pct     =("product_cube_pct", "median"),
        outside_map_sites    =("has_outside_map",  "sum"),
    )
    for col in ["loc_cube_util_pct", "loc_fill_pct", "product_cube_pct"]:
        trend[col] = trend[col].round(2)
    return trend


# ─────────────────────────────────────────────────────────────────────────────
# REGION SUMMARY
# ─────────────────────────────────────────────────────────────────────────────

def build_region_summary(merged: pd.DataFrame) -> pd.DataFrame:
    region = merged.groupby("regionname", as_index=False).agg(
        sites             =("SiteName",          "count"),
        med_loc_cube_util =("loc_cube_util_pct", "median"),
        med_loc_fill      =("loc_fill_pct",      "median"),
        med_product_cube  =("product_cube_pct",  "median"),
        total_sqft        =("Total_Sq_ft",       "sum"),
        outside_map_sites =("has_outside_map",   "sum"),
    )
    for col in ["med_loc_cube_util", "med_loc_fill", "med_product_cube"]:
        region[col] = region[col].round(1)
    return region


# ─────────────────────────────────────────────────────────────────────────────
# SERIALISE — pandas → JSON-safe list of dicts
# ─────────────────────────────────────────────────────────────────────────────

def to_records(df: pd.DataFrame) -> list[dict]:
    """
    Converts a DataFrame to a list of dicts, safely handling numpy types,
    NaN, and inf values so FastAPI can serialise them without errors.
    """
    # Replace inf/-inf with NaN first, then NaN → None below
    df = df.replace([np.inf, -np.inf], np.nan)
    records = []
    for row in df.to_dict(orient="records"):
        clean = {}
        for k, v in row.items():
            if isinstance(v, float) and (np.isnan(v) or np.isinf(v)):
                clean[k] = None
            elif isinstance(v, np.integer):
                clean[k] = int(v)
            elif isinstance(v, np.floating):
                clean[k] = None if (np.isnan(v) or np.isinf(v)) else float(v)
            elif isinstance(v, np.bool_):
                clean[k] = bool(v)
            else:
                clean[k] = v
        records.append(clean)
    return records