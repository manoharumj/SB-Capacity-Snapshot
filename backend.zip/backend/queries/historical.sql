SET NOCOUNT ON;


IF OBJECT_ID('tempdb.dbo.#Total_locations_created') IS NOT NULL DROP TABLE #Total_locations_created;
CREATE TABLE #Total_locations_created WITH (HEAP, DISTRIBUTION=HASH(fulfillmentcenterid)) AS

WITH dates AS (
    SELECT CalendarDate
    FROM dim_date
    WHERE CalendarDate >= '2022-01-01'
      AND CalendarDate <= GETDATE()
      AND (
          -- Pre-2026: month start only
          (YEAR(CalendarDate) < 2026 AND DAY(CalendarDate) = 1)
          OR
          -- 2026+: Sunday week starts
          (YEAR(CalendarDate) >= 2026 AND DATEPART(WEEKDAY, CalendarDate) = 1)
      )
)
SELECT 
    d.CalendarDate,
	a.FulfillmentCenterId,
	fc.NearestAirport_Code_SequenceNumber+' '+fc.CenterName [SiteName],
	CASE WHEN fc.IsActive=1 THEN 'Active Sites' ELSE 'Closed Sites' END [SiteStatus],
	fc.RegionName,
	a.TypeId,
	CASE WHEN dpt.Type='Pallette' THEN 'Pallet' ELSE dpt.Type END [Space_type],
	COALESCE(dpt.PEConversionFactor,1) [PEConversionFactor],
	CASE 
	WHEN a.TypeId = 1 THEN 0.91
	WHEN a.TypeId = 2 THEN 60
	WHEN a.TypeId = 3 THEN 6.71
	WHEN a.TypeId = 4 THEN 30
	WHEN a.TypeId = 5 THEN 120
	WHEN a.TypeId = 6 THEN 0.11
	WHEN a.TypeId = 7 THEN 2
	WHEN a.TypeId IN (10,11) THEN 3
	WHEN a.typeid = 8 THEN 80
	END Cubeconversionfactor,
    COUNT(a.BinNumber) AS LocationCount,
	COUNT( CASE WHEN fcv.BinNumber IS NULL  THEN a.BinNumber END ) [NonMapLocationCount],
	COUNT(CASE WHEN a.IsReachable=1 THEN a.BinNumber END ) [ReachableLocations]

FROM dates d
LEFT JOIN Hist_ShipbobLive.dbo_Shelf a
    ON d.CalendarDate BETWEEN a.ValidFrom AND a.ValidTo
    AND a.BinTypeId IN (1, 2)
    AND a.Deleted = 0
LEFT JOIN dbo.DIM_FulfillmentCenter fc ON fc.FulfillmentCenterId=a.FulfillmentCenterId
LEFT JOIN dbo.DIM_PackageType dpt ON dpt.Id=a.TypeId
LEFT JOIN sco.FACT_FCValidatedLocations fcv ON fcv.BinNumber=a.BinNumber AND fcv.FulfillmentCenterId = a.FulfillmentCenterId
WHERE fc.FulfillmentCentertypeid IN (1,2)
AND fc.IsTestFulfillmentCenter=0
GROUP BY
  d.CalendarDate,
	a.FulfillmentCenterId,
	fc.NearestAirport_Code_SequenceNumber+' '+fc.CenterName ,
	CASE WHEN fc.IsActive=1 THEN 'Active Sites' ELSE 'Closed Sites' END ,
	fc.RegionName,
	a.TypeId,
	CASE WHEN dpt.Type='Pallette' THEN 'Pallet' ELSE dpt.Type END,
	COALESCE(dpt.PEConversionFactor,1),
	CASE 
	WHEN a.TypeId = 1 THEN 0.91
	WHEN a.TypeId = 2 THEN 60
	WHEN a.TypeId = 3 THEN 6.71
	WHEN a.TypeId = 4 THEN 30
	WHEN a.TypeId = 5 THEN 120
	WHEN a.TypeId = 6 THEN 0.11
	WHEN a.TypeId = 7 THEN 2
	WHEN a.TypeId IN (10,11) THEN 3
	WHEN a.typeid = 8 THEN 80
	END;


IF OBJECT_ID('tempdb.dbo.#Total_locations_occupied') IS NOT NULL DROP TABLE #Total_locations_occupied;
CREATE TABLE #Total_locations_occupied WITH (HEAP, DISTRIBUTION=HASH(fulfillmentcenterid)) AS

WITH dates AS (
    SELECT CalendarDate
    FROM dim_date
    WHERE CalendarDate >= '2022-01-01'
      AND CalendarDate <= GETDATE()
      AND (
          (YEAR(CalendarDate) < 2026 AND DAY(CalendarDate) = 1)
          OR
          (YEAR(CalendarDate) >= 2026 AND DATEPART(WEEKDAY, CalendarDate) = 1)
      )
),
Inventory_Attribute AS (
SELECT DISTINCT InventoryId
FROM Hist_ShipbobLive.dbo_InventoryAttributeMapping iam 
WHERE iam.DWIsCurrent = 1 AND iam.AttributeId IN (5,6,7,12,13,14)
)

SELECT 
    fis.SnapshotDate,
	a.FulfillmentCenterId,
	fc.NearestAirport_Code_SequenceNumber+' '+fc.CenterName [SiteName],
	CASE WHEN fc.IsActive=1 THEN 'Active Sites' ELSE 'Closed Sites' END [SiteStatus],
	fc.RegionName,
	a.TypeId,
	case WHEN dpt.Type='Pallette' THEN 'Pallet' ELSE dpt.Type END [Space_type],
	COALESCE(dpt.PEConversionFactor,1) [PEConversionFactor],
	CASE 
	WHEN a.TypeId = 1 THEN 0.91
	WHEN a.TypeId = 2 THEN 60
	WHEN a.TypeId = 3 THEN 6.71
	WHEN a.TypeId = 4 THEN 30
	WHEN a.TypeId = 5 THEN 120
	WHEN a.TypeId = 6 THEN 0.11
	WHEN a.TypeId = 7 THEN 2
	WHEN a.TypeId IN (10,11) THEN 3
	WHEN a.typeid = 8 THEN 80
	END Cubeconversionfactor,
    COUNT(DISTINCT a.BinNumber) AS LocationCount,
	COUNT(DISTINCT  CASE WHEN fcv.BinNumber IS NULL  THEN a.BinNumber END ) [NonMapLocationCount],
	COUNT(DISTINCT CASE WHEN a.IsReachable=1 THEN a.BinNumber END ) [ReachableLocations],
	SUM((fis.quantity*(fi.LengthDec*fi.WidthDec*fi.HeightDec))/1728) [TotalCubeStored],
	SUM( CASE WHEN ia.InventoryId IS NOT NULL THEN (fis.quantity*(fi.LengthDec*fi.WidthDec*fi.HeightDec))/1728 END ) [Packaging_mat_cube],
	SUM(CASE WHEN fcv.binnumber is NULL THEN (fis.quantity*(fi.LengthDec*fi.WidthDec*fi.HeightDec))/1728 END) [CubeStoredOutsideMap],
	COUNT(DISTINCT fi.InventoryId) [dist_SKUs],
	COUNT(DISTINCT fi.UserId) [#merchants],
	SUM(fis.Quantity) [units_stored]

FROM dbo.Fact_InventoryDailySnapshot fis
JOIN dates b ON b.CalendarDate=fis.SnapshotDate
LEFT JOIN dbo.DIM_Shelf a ON a.ShelfId=fis.ShelfId
LEFT JOIN dbo.DIM_FulfillmentCenter fc ON fc.FulfillmentCenterId=a.FulfillmentCenterId
LEFT JOIN dbo.DIM_PackageType dpt ON dpt.Id=a.TypeId
LEFT JOIN fact_item fi ON fi.inventoryid=fis.inventoryid
LEFT JOIN Inventory_Attribute ia ON ia.inventoryid=fi.inventoryid
LEFT JOIN sco.FACT_FCValidatedLocations fcv ON fcv.BinNumber=fis.BinNumber AND fcv.FulfillmentCenterId=fis.FulfillmentCenterId
WHERE fc.FulfillmentCentertypeid IN (1,2)
AND fc.IsTestFulfillmentCenter=0
AND a.BinTypeId IN (1, 2)
AND a.Deleted=0

GROUP BY
  fis.SnapshotDate,
	a.FulfillmentCenterId,
	fc.NearestAirport_Code_SequenceNumber+' '+fc.CenterName ,
	CASE WHEN fc.IsActive=1 THEN 'Active Sites' ELSE 'Closed Sites' END ,
	fc.RegionName,
	a.TypeId,
	case WHEN dpt.Type='Pallette' THEN 'Pallet' ELSE dpt.Type END,
	COALESCE(dpt.PEConversionFactor,1),
	CASE 
	WHEN a.TypeId = 1 THEN 0.91
	WHEN a.TypeId = 2 THEN 60
	WHEN a.TypeId = 3 THEN 6.71
	WHEN a.TypeId = 4 THEN 30
	WHEN a.TypeId = 5 THEN 120
	WHEN a.TypeId = 6 THEN 0.11
	WHEN a.TypeId = 7 THEN 2
	WHEN a.TypeId IN (10,11) THEN 3
	WHEN a.typeid = 8 THEN 80
	END;



WITH dates AS (
    SELECT CalendarDate [Weekstart]
    FROM dim_date
    WHERE CalendarDate >= '2022-01-01'
      AND CalendarDate <= GETDATE()
      AND (
          (YEAR(CalendarDate) < 2026 AND DAY(CalendarDate) = 1)
          OR
          (YEAR(CalendarDate) >= 2026 AND DATEPART(WEEKDAY, CalendarDate) = 1)
      )
),
basedata AS (
SELECT 
Weekstart,
a.FulfillmentCenterId,
a.SiteName,
a.RegionName,
a.SiteStatus,
a.TypeId,
a.Space_type,
a.PEConversionFactor,
a.Cubeconversionfactor,
a.LocationCount [Total_created_locations],
a.NonMapLocationCount [Total_Non_Map_created_locations],
a.ReachableLocations [Total_reachable_created_locations],
b.LocationCount [Occupied_locations],
b.NonMapLocationCount [Occupied_Non_Map_locations],
b.ReachableLocations [Occupied_reachable_locations],
b.TotalCubeStored,
b.Packaging_mat_cube,
b.dist_SKUs,
b.#merchants,
b.units_stored,
CubeStoredOutsideMap


FROM dates d
LEFT JOIN dbo.#Total_locations_created a ON a.CalendarDate=d.Weekstart
LEFT JOIN dbo.#Total_locations_occupied b 
ON b.FulfillmentCenterId = a.FulfillmentCenterId
AND b.TypeId = a.TypeId
AND a.CalendarDate=b.SnapshotDate
)

SELECT 
weekstart,
basedata.SiteName,
regionname,
basedata.SiteStatus,
basedata.TypeId,
basedata.dist_SKUs,
SUM(basedata.Total_created_locations * basedata.Cubeconversionfactor) [Total_cube_capacity],
SUM(basedata.Occupied_locations* basedata.Cubeconversionfactor) [Total_cube_capacity_occupied],
SUM(basedata.TotalCubeStored) [Product_cube_stored],
SUM(CubeStoredOutsideMap) [CubeStoredOutsideMap],
SUM(Packaging_mat_cube) [Packaging_mat_cube],
SUM(basedata.Occupied_locations) [OccupiedLocations],
SUM(basedata.Total_created_locations) [CreatedLocations],
SUM(basedata.Total_reachable_created_locations ) [Total_reachable_locs],
SUM(basedata.Occupied_reachable_locations  ) [Occupied_reachable_locs]

FROM basedata

where basedata.sitestatus='Active Sites'

GROUP BY 
weekstart,
basedata.SiteName,
regionname,
basedata.SiteStatus,
basedata.TypeId,
basedata.dist_SKUs
ORDER BY weekstart