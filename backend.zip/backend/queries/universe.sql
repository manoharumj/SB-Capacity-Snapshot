/* =======================================
   Week start (Sunday)
   ======================================= */
DECLARE @Today DATE = CAST(GETDATE() AS DATE);
DECLARE @WeekStartSunday DATE = DATEADD(WEEK, DATEDIFF(WEEK, '19000107', @Today), '19000107');

;WITH
/* =======================================
   1) Weekly scorecard (this week only)
   ======================================= */
scorecard AS (
    SELECT
        UPPER(LTRIM(RTRIM(REPLACE(sc.SiteCode, ' ', '')))) AS SiteCodeKey,  -- e.g., 'ABE-1'
        sc.weekStartdate,
        sc.SiteCode,
        sc.status                        AS SC_status,
        sc.DangerousGoodsEligibility     AS WC_DG_flag,
        sc.[HazmatEnabled?]              AS WC_Haz_flag,
        sc.class2dgcertified             AS WC_Class2_flag,
        sc.class3dgcertified             AS WC_Class3_flag,
        sc.[Class4-9DGCertified]         AS WC_Class4_9_flag,
        sc.[TempControlled?]             AS WC_TempControl_flag,
        sc.B2BEnabled                    AS WC_B2B_flag,    -- scorecard-only
        sc.[GFSI+Certified]              AS GMP_GFSI_flag
    FROM sco.FACT_WeeklyCapacityScorecard sc
    WHERE sc.weekStartdate = @WeekStartSunday
),

/* =======================================
   2) Active FCs (SFN / SIC / HUB/FMS)
   ======================================= */
active_fc AS (
    SELECT
        fc.FulfillmentCenterId,
        fc.NearestAirport_Code_SequenceNumber + ' ' + fc.CenterName AS SiteName,
        fc.RegionName,
        UPPER(LTRIM(RTRIM(REPLACE(fc.NearestAirport_Code_SequenceNumber, ' ', '')))) AS FcSiteCodeKey,
        fc.FulfillmentCenterTypeId,
        fc.FulfillmentCenterTypeDesc,
        fc.IsActive,
        fc.IsTestFulfillmentCenter,
        CAST(fc.InsertDate AS DATE) AS FMS_LiveDate,
		fc.StreetAddress1+', '+fc.Country+', '+fc.ZipCode [Address],
		CASE WHEN hub.CenterName IS NULL THEN 'Not Part of Hub Network' ELSE hub.CenterName end AS Hub,
		fc.Country
		FROM dbo.DIM_FulfillmentCenter fc
	LEFT JOIN Hist_InboundManagement.dbo_ReceivingHubToSpokeMapping h ON h.SpokeFulfillmentCenterId=fc.FulfillmentCenterId
	LEFT JOIN dbo.DIM_FulfillmentCenter hub ON hub.FulfillmentCenterId=h.HubFulfillmentCenterId
    WHERE fc.FulfillmentCenterTypeId IN (1, 2, 5)      -- include Hubs (5)
      AND fc.IsTestFulfillmentCenter = 0
      AND fc.IsActive=1
      
),

/* =======================================
   3) FC Building Info – include hubs; no snapshot column used
   ======================================= */
fc_info AS (
    SELECT
        fci.FulfillmentCenterId,
        fci.AirportCode,
        fci.FulfillmentCenterStatus          AS BI_status,
        fci.GoLiveDate                       AS FCI_LiveDate,
        fci.YearBuilt,
        fci.SuqareFootageTotalBuilding       AS Total_Sq_ft,
        fci.SuqareFootageShipbobArea         AS SB_Sq_ft,
        fci.HeatingType,
        fci.HeatingFuel,
        fci.SecurityAlarms,
        fci.GuardPresence,
        fci.SprinklerSystems,
        fci.FireAlarms,
        fci.PestControlTypes,
        fci.FDARegistrationNumber,
        fci.ReceivingDockDoors,
        fci.OutboundDockDoors,
        fci.SecureLotForTrailers,
        fci.ClearanceHeight,
        fci.HeavyWeightOver50lbs             AS Heavy_wt_items,
        fci.OversizeItemsGreaterThan48x40x54 AS Oversize_items,
        fci.TemperatureControl               AS BI_TempControl_flag,
        fci.DangerousGoods                   AS BI_DG_flag,
        fci.HAZMAT                           AS BI_Haz_flag,
        fci.FoodSafetyCertificationGFSIOrSQF AS BI_GMP_GFSI_flag,
        fci.Open7Days,
        fci.TotalDockSpaceInboundAndOutboundInSQFT,
        fci.InboundDockSpaceInSQFT,
        fci.OutboundDockSpaceInSQFT,
        fci.SheetReference,
		fci.CloseOrContractEndDate

    FROM sco.DIM_FCBuildingInformationSnapshot fci
    WHERE
        fci.SheetReference IN ('closed sfn + sic  locations', 'sic + sfn locations')
        OR fci.SheetReference LIKE '%hub%'
),

/* =======================================
   4) fc_info → SiteCodeKey via DIM_FulfillmentCenter
   ======================================= */
fc_info_keys AS (
    SELECT
        fi.FulfillmentCenterId,
        UPPER(LTRIM(RTRIM(REPLACE(fc.NearestAirport_Code_SequenceNumber, ' ', '')))) AS FcSiteCodeKeyFromInfo
    FROM fc_info fi
    JOIN dbo.DIM_FulfillmentCenter fc
      ON fc.FulfillmentCenterId = fi.FulfillmentCenterId
),

/* =======================================
   5) Universe of site codes (union of all sources)
   ======================================= */
universe AS (
    SELECT DISTINCT FcSiteCodeKey AS SiteCodeKey FROM active_fc
    UNION
    SELECT DISTINCT SiteCodeKey    AS SiteCodeKey FROM scorecard
    UNION
    SELECT DISTINCT FcSiteCodeKeyFromInfo AS SiteCodeKey FROM fc_info_keys
),

/* =======================================
   6) Join Universe → Active FC → Scorecard → FC Info
   ======================================= */
joined AS (
    SELECT
        u.SiteCodeKey,

        -- Active FC (may be NULL if site not active)
        afc.FulfillmentCenterId,
        afc.SiteName,
        afc.RegionName,
        afc.FcSiteCodeKey,
        afc.FulfillmentCenterTypeId,
        afc.FulfillmentCenterTypeDesc,
        afc.IsActive,
        afc.FMS_LiveDate,
		afc.Address,
		afc.Hub,
		afc.Country,
        -- Scorecard (may be NULL if missing this week)
        sc.weekStartdate             AS SC_WeekStart,
        sc.SiteCode                  AS SC_SiteCode,
        sc.SC_status,
        sc.WC_DG_flag,
        sc.WC_Haz_flag,
        sc.WC_Class2_flag,
        sc.WC_Class3_flag,
        sc.WC_Class4_9_flag,
        sc.WC_TempControl_flag,
        sc.WC_B2B_flag,
        sc.GMP_GFSI_flag,

        -- FC Info (via FC id resolved from AF or FI keys)
        fi.AirportCode,
        fi.BI_status,
        fi.FCI_LiveDate,
        fi.BI_TempControl_flag,
        fi.BI_DG_flag,
        fi.BI_Haz_flag,
        fi.BI_GMP_GFSI_flag,

        -- Building meta
        fi.YearBuilt,
        fi.Total_Sq_ft,
        fi.SB_Sq_ft,
        fi.HeatingType,
        fi.HeatingFuel,
        fi.SecurityAlarms,
        fi.GuardPresence,
        fi.SprinklerSystems,
        fi.FireAlarms,
        fi.PestControlTypes,
        fi.FDARegistrationNumber,
        fi.ReceivingDockDoors,
        fi.OutboundDockDoors,
        fi.SecureLotForTrailers,
        fi.ClearanceHeight,
        fi.Heavy_wt_items,
        fi.Oversize_items,
        fi.Open7Days,
        fi.TotalDockSpaceInboundAndOutboundInSQFT,
        fi.InboundDockSpaceInSQFT,
        fi.OutboundDockSpaceInSQFT,
        fi.SheetReference,
		fi.CloseOrContractEndDate
    FROM universe u
    LEFT JOIN active_fc     afc ON afc.FcSiteCodeKey          = u.SiteCodeKey
    LEFT JOIN scorecard     sc  ON sc.SiteCodeKey              = u.SiteCodeKey
    LEFT JOIN fc_info_keys  fik ON fik.FcSiteCodeKeyFromInfo   = u.SiteCodeKey
    LEFT JOIN fc_info       fi  ON fi.FulfillmentCenterId      = COALESCE(afc.FulfillmentCenterId, fik.FulfillmentCenterId)
),

/* =======================================
   7) Exception flags (kept for quick diagnostics)
   ======================================= */
flagged AS (
    SELECT
        j.*,

        /* Active site present but missing from weekly scorecard (e.g., EWR-9 / LTN-1) */
        CASE
            WHEN j.FulfillmentCenterId IS NOT NULL AND j.SC_WeekStart IS NULL
                THEN 1 ELSE 0
        END AS ActiveButMissingInScorecard,

        /* Scorecard lists site but no active FC mapping */
        CASE
            WHEN j.SC_WeekStart IS NOT NULL AND j.FulfillmentCenterId IS NULL
                THEN 1 ELSE 0
        END AS InScorecardButNotActive,

        /* Active site with no building-info record */
        CASE
            WHEN j.FulfillmentCenterId IS NOT NULL AND j.BI_status IS NULL
                THEN 1 ELSE 0
        END AS Missing_FC_Info,

        /* Field mismatches (only when both scorecard and building info exist) */
        CASE
            WHEN j.FulfillmentCenterId IS NOT NULL AND j.SC_WeekStart IS NOT NULL
             AND TRY_CONVERT(NVARCHAR(50), j.SC_status) <> TRY_CONVERT(NVARCHAR(50), j.BI_status)
                THEN 1 ELSE 0
        END AS Status_Mismatch,

        CASE
            WHEN j.FulfillmentCenterId IS NOT NULL AND j.SC_WeekStart IS NOT NULL
             AND TRY_CONVERT(NVARCHAR(50), j.WC_DG_flag) <> TRY_CONVERT(NVARCHAR(50), j.BI_DG_flag)
                THEN 1 ELSE 0
        END AS DG_Mismatch,

        CASE
            WHEN j.FulfillmentCenterId IS NOT NULL AND j.SC_WeekStart IS NOT NULL
             AND TRY_CONVERT(NVARCHAR(50), j.WC_Haz_flag) <> TRY_CONVERT(NVARCHAR(50), j.BI_Haz_flag)
                THEN 1 ELSE 0
        END AS Hazmat_Mismatch,

        CASE
            WHEN j.FulfillmentCenterId IS NOT NULL AND j.SC_WeekStart IS NOT NULL
             AND TRY_CONVERT(NVARCHAR(50), j.WC_TempControl_flag) <> TRY_CONVERT(NVARCHAR(50), j.BI_TempControl_flag)
                THEN 1 ELSE 0
        END AS TempControl_Mismatch,

        /* No B2B mismatch – not present in FC Info */
        CASE
            WHEN j.FulfillmentCenterId IS NOT NULL AND j.SC_WeekStart IS NOT NULL
             AND TRY_CONVERT(NVARCHAR(50), j.GMP_GFSI_flag) <> TRY_CONVERT(NVARCHAR(50), j.BI_GMP_GFSI_flag)
                THEN 1 ELSE 0
        END AS GFSI_Mismatch
    FROM joined j
)


/* =======================================
   9) Full merged view – for verification/exports
   ======================================= */
SELECT
    SiteCodeKey,
    CASE WHEN flagged.IsActive IS NULL THEN 'Not in FMS'
       ELSE 'Existing' END AS SiteActiveStatus,
    SC_WeekStart,
    SC_SiteCode,
    FulfillmentCenterId,
    SiteName,
    RegionName,
    FcSiteCodeKey,
    FulfillmentCenterTypeId,
    FulfillmentCenterTypeDesc,
    IsActive,
    FMS_LiveDate,
	Address,
	Hub,
	Country,

    -- Scorecard
    SC_status,
    WC_DG_flag,
    WC_Haz_flag,
    WC_Class2_flag,
    WC_Class3_flag,
    WC_Class4_9_flag,
    WC_TempControl_flag,
    WC_B2B_flag,
    GMP_GFSI_flag,

    -- Building info
    AirportCode,
    BI_status,
    FCI_LiveDate,
    BI_TempControl_flag,
    BI_DG_flag,
    BI_Haz_flag,
    BI_GMP_GFSI_flag,

    -- Building meta
    YearBuilt,
    Total_Sq_ft ,
    SB_Sq_ft,
    HeatingType,
    HeatingFuel,
    SecurityAlarms,
    GuardPresence,
    SprinklerSystems,
    FireAlarms,
    PestControlTypes,
    FDARegistrationNumber,
    ReceivingDockDoors ,
    OutboundDockDoors,
    SecureLotForTrailers,
    ClearanceHeight,
    Heavy_wt_items,
    Oversize_items,
    Open7Days,
    TotalDockSpaceInboundAndOutboundInSQFT,
    InboundDockSpaceInSQFT,
    OutboundDockSpaceInSQFT,
    SheetReference,
	CloseOrContractEndDate
FROM flagged

WHERE (flagged.SheetReference IS NULL
   OR flagged.SheetReference NOT IN ('closed sfn + sic  locations')
   )
AND CASE WHEN flagged.IsActive IS NULL THEN 'Not in FMS'
       ELSE 'Existing' END = 'Existing'
ORDER BY
    SiteCodeKey;